<?php
session_start();
if(empty($_SESSION['user'])){
    header("location: ../index.php");
} else {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/style.css">
    <title>Document</title>
    <style>
    .empty-button {
      border: none;
      background: none;
      color: blue;
      text-decoration: underline;
      cursor: pointer;
    }

    .card {
      background-color: lightgray;
      padding: 20px;
      margin-top: 10px;
      display: none;
    }

    .product-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      margin-bottom: 20px;
    }

    .product-container .product {
      width: calc(33.33% - 10px);
      margin-bottom: 10px;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .product-image {
      width: 200px;
      height: 200px;
      background-color: gray;
      margin-bottom: 10px;
    }

    .product-name {
      font-weight: bold;
      margin-bottom: 5px;
    }

    .product-price {
      margin-bottom: 5px;
    }

    .product-buttons {
      display: flex;
    }

    .product-button {
      margin-right: 10px;
      position: relative;
      transition: transform 0.3s ease-in-out;
    }

    .product-button:hover {
      transform: scale(1.1);
    }

    .product-button .cart-badge {
      position: absolute;
      top: -5px;
      right: -5px;
      background-color: red;
      color: #fff;
      border-radius: 50%;
      padding: 2px 5px;
      font-size: 12px;
    }

    .header {
      background-color: #333;
      color: #fff;
      padding: 20px;
      text-align: center;
    }

    .dropdown {
      position: relative;
      display: inline-block;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #f9f9f9;
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
      z-index: 1;
    }

    .dropdown-content a {
      color: black;
      padding: 12px 16px;
      text-decoration: none;
      display: block;
    }

    .dropdown:hover .dropdown-content {
      display: block;
    }

    .cart-item {
      display: flex;
      align-items: center;
      padding: 10px;
      border-bottom: 1px solid #ddd;
    }

    .cart-item-image {
      width: 50px;
      height: 50px;
      background-color: gray;
      margin-right: 10px;
    }

    .cart-item-details {
      flex: 1;
    }

    .cart-item-name {
      font-weight: bold;
    }

    .cart-item-ml {
      color: gray;
      margin-bottom: 5px;
    }

    .cart-item-price {
      font-weight: bold;
      margin-bottom: 5px;
    }

    .cart-item-buy {
      display: flex;
      align-items: center;
    }

    .cart-item-buy-button {
      margin-left: 10px;
    }

    .fas.fa-cart-plus::before {
      content: "\f217";
    }

    .fas.fa-check::before {
      content: "\f00c";
    }

    .far.fa-heart::before {
      content: "\f08a";
    }

    .fas.fa-heart::before {
      content: "\f004";
      color: red;
    }
  </style>
</head>
<body>
 <div class="header">
    <h1>Meu Cabeçalho</h1>
    <nav>
      <a href="#" class="product-button" id="cart-button">
        <i class="fas fa-shopping-cart"></i>
        <span class="cart-badge">0</span>
      </a>
    </nav>
  </div>

  <div class="content">
    <div class="product-container">
      <div class="product">
        <div class="product-image"></div>
        <div class="product-name">Nome do Produto 1</div>
        <div class="product-price">R$ 99,99</div>
        <div class="product-buttons">
          <button class="product-button" onclick="addToCart(this)">
            <i class="fas fa-cart-plus"></i>
          </button>
          <button class="product-button" onclick="toggleFavorite(this)">
            <i class="far fa-heart"></i>
          </button>
        </div>
      </div>

      <div class="product">
        <div class="product-image"></div>
        <div class="product-name">Nome do Produto 2</div>
        <div class="product-price">R$ 79,99</div>
        <div class="product-buttons">
          <button class="product-button" onclick="addToCart(this)">
            <i class="fas fa-cart-plus"></i>
          </button>
          <button class="product-button" onclick="toggleFavorite(this)">
            <i class="far fa-heart"></i>
          </button>
        </div>
      </div>

      <div class="product">
        <div class="product-image"></div>
        <div class="product-name">Nome do Produto 3</div>
        <div class="product-price">R$ 149,99</div>
        <div class="product-buttons">
          <button class="product-button" onclick="addToCart(this)">
            <i class="fas fa-cart-plus"></i>
          </button>
          <button class="product-button" onclick="toggleFavorite(this)">
            <i class="far fa-heart"></i>
          </button>
        </div>
      </div>
    </div>

    <div id="cart-items">
      <!-- Itens do carrinho serão adicionados dinamicamente aqui -->
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
  <script>
    const emptyButtons = document.querySelectorAll('.empty-button');
    const cards = document.querySelectorAll('.card');
    let cartQuantity = 0;

    const cartButton = document.getElementById('cart-button');
    const cartBadge = document.querySelector('.cart-badge');

    function addToCart(button) {
      const product = button.parentNode.parentNode;
      const productName = product.querySelector('.product-name').textContent;

      cartQuantity++;
      cartBadge.textContent = cartQuantity;

      const cartItemsContainer = document.getElementById('cart-items');

      const cartItem = document.createElement('div');
      cartItem.classList.add('cart-item');

      const cartItemImage = document.createElement('div');
      cartItemImage.classList.add('cart-item-image');

      const cartItemDetails = document.createElement('div');
      cartItemDetails.classList.add('cart-item-details');

      const cartItemName = document.createElement('div');
      cartItemName.classList.add('cart-item-name');
      cartItemName.textContent = productName;

      const cartItemML = document.createElement('div');
      cartItemML.classList.add('cart-item-ml');
      cartItemML.textContent = 'ml';

      const cartItemPrice = document.createElement('div');
      cartItemPrice.classList.add('cart-item-price');
      cartItemPrice.textContent = product.querySelector('.product-price').textContent;

      const cartItemBuy = document.createElement('div');
      cartItemBuy.classList.add('cart-item-buy');

      const cartItemBuyButton = document.createElement('button');
      cartItemBuyButton.classList.add('cart-item-buy-button');
      const cartItemBuyButtonIcon = document.createElement('i');
      cartItemBuyButtonIcon.classList.add('fas', 'fa-shopping-cart');
      cartItemBuyButton.appendChild(cartItemBuyButtonIcon);

      cartItemDetails.appendChild(cartItemName);
      cartItemDetails.appendChild(cartItemML);
      cartItemDetails.appendChild(cartItemPrice);

      cartItemBuy.appendChild(cartItemBuyButton);

      cartItem.appendChild(cartItemImage);
      cartItem.appendChild(cartItemDetails);
      cartItem.appendChild(cartItemBuy);

      cartItemsContainer.appendChild(cartItem);
    }

    function toggleFavorite(button) {
      button.querySelector('.fa-heart').classList.toggle('fas');
      button.querySelector('.fa-heart').classList.toggle('far');
    }

    for (let i = 0; i < emptyButtons.length; i++) {
      emptyButtons[i].addEventListener('click', function() {
        cards[i].style.display = 'block';
      });
    }

    cartButton.addEventListener('click', function() {
      // Adicione aqui a lógica para exibir o carrinho ou executar outras ações relacionadas ao clique no botão do carrinho
    });
  </script>
</body>
</html>
<?php
}
?>