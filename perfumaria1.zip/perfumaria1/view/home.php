<?php
session_start();
if(empty($_SESSION['user'])){
    header("location: ../index.php");
} else {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/style.css">
    <title>Document</title>
</head>
<body>
  
<header>
        <h1>Perfumaria</h1>
         <div id="nav-links">
        <nav>
            <ul>
              <li><a href="Index.html">Home</a></li>
                <li><a href="catalog.html">Catálogo</a></li>
</nav>  
    </header>
    <header>
<div id="cart-icon" onclick="exibirCarrinho()">
  <i class="fa fa-shopping-cart"></i>
  <span id="cart-item-count">0</span>
</div>

<div id="cart-overlay">
  <div id="cart-content">
    <h3>Itens no Carrinho</h3>
    <ul id="cart-items"></ul>
    <button onclick="fecharCarrinho()">Fechar</button>
  </div>
</div>
</div>
  </header>
<div class="grid-container">
  <div id=""class="grid-item">
    <img   src="../assets/perfume.png" alt="Rosas dos campos">
    <h3>Rosas dos Campos</h3>
    <p>R$ 100,00</p>
      <li><button onclick="adicionarItemAoCarrinho('Produto 1')">Adicionar ao Carrinho</button></li>
  </div>
  <div class="grid-item">
    <img src="../assets/perfume2.png" alt="Produto 2">
    <h3>Produto 2</h3>
    <p>R$ 200,90</p>
      <li> <button onclick="adicionarItemAoCarrinho('Produto 1')">Adicionar ao Carrinho</button></li>
  </div>
  <div class="grid-item">
    <img src="../assets/perfume3.png" alt="Produto 3">
    <h3>Produto 3</h3>
    <p>R$ 40,50</p>
      <li><button onclick="adicionarItemAoCarrinho('Produto 1')">Adicionar ao Carrinho</button></li>
  </div>
  
  <script>
var cartItemCount = 0;
var cartItems = [];

function exibirCarrinho() {
  var cartOverlay = document.getElementById('cart-overlay');
  cartOverlay.style.display = 'block';
}

function adicionarItemAoCarrinho() {
  cartItemCount++;
  cartItems.push('Produto' +cartItemCount);
  atualizarContagemDoCarrinho();
  atualizarItensNoCarrinho();
}

function removerItemDoCarrinho(index) {
  cartItems>=0;
  cartItemCount--;
  cartItems.splice(index, 1);
  atualizarContagemDoCarrinho();
  atualizarItensNoCarrinho();
}

function atualizarContagemDoCarrinho() {
  var cartItemSpan = document.getElementById('cart-item-count');
  cartItemSpan.textContent = cartItemCount.toString();
}

function atualizarItensNoCarrinho() {
  var cartItemsList = document.getElementById('cart-items');
  cartItemsList.innerHTML = '';

  for (var i = 0; i < cartItems.length; i++) {
    var item = cartItems[i];
    var listItem = document.createElement('li');
    listItem.textContent = item;
    var removeButton = document.createElement('button');
    removeButton.textContent = 'Remover';
    removeButton.setAttribute('data-index', i);
    removeButton.addEventListener('click', function(e) {
      var index = e.target.getAttribute('data-index');
      removerItemDoCarrinho(index);
    });
    listItem.appendChild(removeButton);
    cartItemsList.appendChild(listItem);
  }
}

function fecharCarrinho() {
  var cartOverlay = document.getElementById('cart-overlay');
  cartOverlay.style.display = 'none';
}
</body>
</html>
<?php
}
?>