<?php
include "../model/conexao.php";
session_start();
if(isset($_POST['cad'])){
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $compare = "SELECT * FROM cadastros WHERE email = '$email'";
    $result = $con->query($compare);

    if($result->num_rows == 0){
        $sql = "INSERT INTO cadastros VALUES('$nome','$email','$senha')";
        $con->query($sql);
        echo "Usuário cadastrado";
    } else {
        echo "Usuário já existe";
    }
} else {
    header("location: ../index.php");
}
?>