<?php
session_start();
include "../model/conexao.php";
if(isset($_POST['login'])){
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $sql = "SELECT * FROM cadastros WHERE email = '$email' ";
    $result = $con->query($sql);
    $row = $result->fetch_assoc();
    if($email == $row['Email'] && $senha == $row['senha']){
        $_SESSION['user'] = md5(sha1($senha));
        header("location: ../view/home.php");
    } else {
        echo "Email ou senha incorretos";
    }

} else {
    header("location: ../index.php");
}

?>