<?php 
$servidor = "localhost";
$user = "root";
$senha = "";
$banco = "Perfumaria";

$con = new mysqli($servidor,$user,$senha,$banco);
?>